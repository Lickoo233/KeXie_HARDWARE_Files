# Plotclock
小贱钟

拿着手机不知所措的同学，请打包下载，推荐使用电脑打包下载后再看。手机无法在线浏览。 下载是按绿色的 Clone or Download 按钮下载zip的打包文件。 不会用的可以看一下Github使用教程： https://www.bilibili.com/video/BV1ff4y1975o/

还是不会用的可以到百度下载程序资料大全包下载链接: https://pan.baidu.com/s/1jAKLyw1U7uZOfD-dVMVJpQ 提取码: rg9f （9.28最后更新）

推荐直接使用Arduino.cc官网的web版编译器 部分内容可能翻墙后更方便，推荐一个翻墙工具， https://github.com/bannedbook/fanqiang/wiki

部分系统有不不能正常安装驱动的情况，可以手工安装驱动（CH340 CH341都可以适用）。WIN驱动下载链接：https://sparks.gogo.co.nz/assets/_site_/downloads/CH34x_Install_Windows_v3_4.zip 其他系统请到 https://sparks.gogo.co.nz/ch340.html （CH34X驱动大全或自行搜索）

请勿使用旺旺咨询任何关于程序调试、翻墙工具使用的任何问题。我们只能保证程序可以运行，关于程序的任何问题，请自行解决。如果没有调试运行Arduino程序的基础知识，请谨慎购买。
